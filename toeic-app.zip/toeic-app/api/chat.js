// =====================================================================
// /api/chat.js — Proxy serverless vers l'API Anthropic (Vercel)
// ---------------------------------------------------------------------
// Ce fichier s'exécute côté serveur sur Vercel. La clé API n'est JAMAIS
// envoyée au navigateur : elle est lue depuis la variable d'environnement
// ANTHROPIC_API_KEY que tu configures dans le dashboard Vercel.
//
// Le frontend envoie { messages, system, max_tokens, model } en POST,
// le serveur ajoute la clé secrète, appelle Anthropic, renvoie la réponse.
// =====================================================================

const DEFAULT_MODEL = "claude-sonnet-4-6"; // qualité quasi-Opus, rapide, ~3¢/correction
const ALLOWED_MODELS = new Set([
  "claude-sonnet-4-6",
  "claude-haiku-4-5-20251001",
  "claude-opus-4-7",
]);

export default async function handler(req, res) {
  // --- CORS (utile si tu testes depuis un autre domaine ; sinon same-origin) ---
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") { res.status(204).end(); return; }

  const apiKey = process.env.ANTHROPIC_API_KEY;

  // --- Health-check léger : ne consomme AUCUN token ---
  // Le frontend l'appelle au démarrage pour savoir si l'IA est dispo.
  if (req.method === "GET") {
    res.status(200).json({ ok: true, hasKey: !!apiKey });
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "Méthode non autorisée. Utilise POST." });
    return;
  }

  if (!apiKey) {
    res.status(500).json({
      error: "Clé API non configurée. Ajoute ANTHROPIC_API_KEY dans les variables d'environnement Vercel."
    });
    return;
  }

  // Parse du body (Vercel le parse déjà en général, mais on sécurise)
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  const { messages, system, max_tokens, model } = body || {};

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: "Le champ 'messages' (tableau non vide) est requis." });
    return;
  }

  // Garde-fou usage perso : on plafonne pour éviter les surprises de facturation
  const safeMaxTokens = Math.min(Math.max(parseInt(max_tokens, 10) || 1500, 1), 4096);
  const safeModel = ALLOWED_MODELS.has(model) ? model : DEFAULT_MODEL;

  const payload = {
    model: safeModel,
    max_tokens: safeMaxTokens,
    messages,
  };
  if (system && typeof system === "string") payload.system = system;

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(payload),
    });

    const data = await anthropicRes.json();

    if (!anthropicRes.ok) {
      // On relaie l'erreur Anthropic telle quelle (utile pour debugger)
      res.status(anthropicRes.status).json({
        error: data?.error?.message || "Erreur de l'API Anthropic",
        detail: data,
      });
      return;
    }

    // On extrait le texte pour simplifier le frontend, tout en renvoyant le brut
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    res.status(200).json({ text, raw: data, model: safeModel });
  } catch (err) {
    res.status(500).json({ error: "Échec de la requête vers Anthropic.", detail: String(err) });
  }
}
