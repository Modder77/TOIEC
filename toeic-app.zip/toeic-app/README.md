# Atelier TOEIC — PWA augmentée par l'IA

Entraîneur TOEIC complet, installable sur iPhone/Android, avec correction et conseils par l'IA Claude.

## Ce que contient l'app

**8 modules**
1. **Vocabulaire** — 6 thèmes (~90 mots), cartes mémoire + quiz, audio
2. **Listening** — conversations et annonces (synthèse vocale), questions
3. **Reading** — textes professionnels **+ textes générés par l'IA à la volée**
4. **Grammar** — banque de 30 questions Part 5 **+ questions générées par l'IA**
5. **Writing** — rédaction avec **correction IA détaillée** (note, points forts, reformulations)
6. **Speaking** — expression orale : reconnaissance vocale + **évaluation IA** de la transcription
7. **Tuteur IA** — chatbot pour poser toutes tes questions d'anglais / TOEIC
8. **Examen blanc** — simulation chronométrée 20 min avec score

Plus : un **tableau de bord** avec suivi de progression et **conseils personnalisés générés par l'IA**, et un onglet **Paramètres** (statut IA, stats, réinitialisation).

## Architecture

```
toeic-app/
├── index.html        ← toute l'app (frontend, un seul fichier)
├── api/
│   └── chat.js        ← backend serverless : garde ta clé API secrète
├── manifest.json      ← métadonnées PWA
├── sw.js              ← service worker (fonctionnement hors-ligne)
├── vercel.json        ← config (en-têtes de cache)
├── package.json
└── icon-180/192/512.png
```

Le frontend n'appelle **jamais** Anthropic directement : il passe par `/api/chat`, exécuté côté serveur sur Vercel, qui seul connaît la clé. Ta clé n'est donc jamais exposée dans le navigateur.

---

## Déploiement sur Vercel (≈ 5 minutes, gratuit)

### Étape 1 — Récupérer une clé API Anthropic
1. Va sur **console.anthropic.com** → **API Keys** → **Create Key**
2. Copie la clé (commence par `sk-ant-...`). Garde-la secrète.
3. Crédite ton compte de quelques euros (Billing). Un usage perso intensif coûte quelques euros par mois — voir la section Coûts.

### Étape 2 — Déployer
**Option A — Glisser-déposer (le plus simple)**
1. Crée un compte gratuit sur **vercel.com**
2. Installe l'outil en ligne de commande : `npm i -g vercel`
3. Dans le dossier `toeic-app/`, lance : `vercel`
4. Réponds aux questions (accepte les valeurs par défaut). Vercel déploie et te donne une URL.

**Option B — Via GitHub**
1. Crée un dépôt GitHub et pousses-y le contenu de `toeic-app/`
2. Sur vercel.com → **Add New Project** → importe le dépôt → **Deploy**

### Étape 3 — Configurer la clé API
1. Sur le dashboard Vercel de ton projet : **Settings** → **Environment Variables**
2. Ajoute :
   - **Name** : `ANTHROPIC_API_KEY`
   - **Value** : ta clé `sk-ant-...`
   - Coche les 3 environnements (Production, Preview, Development)
3. **Redéploie** : onglet **Deployments** → bouton ⋯ du dernier déploiement → **Redeploy**

### Étape 4 — Vérifier
Ouvre ton URL Vercel. Va dans l'onglet **⚙** : tu dois voir **« ✓ IA active »**. Si tu vois « ⚠ Clé manquante », la variable d'environnement n'est pas prise en compte → vérifie l'orthographe exacte `ANTHROPIC_API_KEY` et redéploie.

---

## Installer sur ton iPhone

1. Ouvre ton URL Vercel dans **Safari** (obligatoirement Safari sur iOS)
2. Bouton **Partager** (⬆ en bas de l'écran)
3. **« Sur l'écran d'accueil »** → **Ajouter**
4. L'icône « A » apparaît sur ton écran d'accueil. Tap dessus : l'app se lance en plein écran.

Sur **Android** : ouvre l'URL dans Chrome → menu ⋮ → « Installer l'application ».

---

## Coûts (usage personnel)

L'app utilise **Claude Sonnet 4.6** (`claude-sonnet-4-6`), facturé par l'API Anthropic à 3 $ / million de tokens en entrée et 15 $ / million en sortie. Ordre de grandeur :

| Action | Coût approximatif |
|---|---|
| Une correction Writing | ~0,03 € |
| Une évaluation Speaking | ~0,02 € |
| Génération de 8 questions de grammaire | ~0,03 € |
| Génération d'un texte de lecture | ~0,02 € |
| Un message au tuteur | ~0,01–0,02 € |
| Conseils personnalisés | ~0,01 € |

Le tableau de bord vérifie la disponibilité de l'IA via un *health-check* qui **ne consomme aucun token**. En pratique, un usage quotidien sérieux revient à quelques euros par mois. Tu peux fixer une limite de dépense mensuelle dans la console Anthropic (Billing → Limits) pour être tranquille.

### Réduire les coûts
- Pour des fonctions plus économiques, tu peux changer le modèle par défaut dans `api/chat.js` (constante `DEFAULT_MODEL`) en `claude-haiku-4-5-20251001` (5× moins cher, qualité un peu en dessous mais très correcte pour la grammaire et le vocabulaire).

---

## Faire une « vraie » app sur les stores (optionnel)

La PWA installée se comporte déjà comme une app native (plein écran, icône, hors-ligne). Si tu veux **en plus** une présence sur l'App Store / Play Store, on peut empaqueter la PWA avec **Capacitor** sans réécrire le code :

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
npx cap init "Atelier TOEIC" com.toi.toeic --web-dir=.
npx cap add ios       # nécessite un Mac + Xcode
npx cap add android   # nécessite Android Studio
npx cap open ios      # compile et publie depuis Xcode
```

Cela demande un compte Apple Developer (99 $/an) pour l'App Store et/ou un compte Google Play (25 $ une fois). Pour un usage perso, l'installation PWA suffit largement et ne coûte rien.

---

## Confidentialité

- Ta **progression** (scores, mots étudiés…) est stockée uniquement dans le navigateur de ton appareil (`localStorage`). Elle ne part sur aucun serveur.
- Les **textes que tu soumets** aux fonctions IA (rédactions, transcriptions orales, questions au tuteur) transitent par ton backend Vercel vers l'API Anthropic, le temps de générer la réponse. Anthropic ne les utilise pas pour entraîner ses modèles via l'API.

---

## Dépannage

| Symptôme | Solution |
|---|---|
| « ⚠ Clé manquante » dans ⚙ | Vérifie `ANTHROPIC_API_KEY` dans Vercel → Settings → Environment Variables, puis **redéploie** |
| « ○ IA hors-ligne » | Tu as ouvert le fichier en local (`file://`). Les fonctions IA exigent le déploiement Vercel |
| Erreur 401 lors d'une correction | Clé API invalide ou compte non crédité (console.anthropic.com → Billing) |
| Erreur 429 | Tu as atteint une limite de débit ; attends quelques secondes |
| Voix de mauvaise qualité (Listening) | Dépend du navigateur ; Safari sur iPhone/Mac a les meilleures voix anglaises |
| Reconnaissance vocale absente (Speaking) | Utilise Safari (iOS) ou Chrome/Edge (ordinateur) |

---

*Construit comme une PWA autonome : un frontend statique + une fonction serverless. Aucune base de données, aucun framework de build.*
